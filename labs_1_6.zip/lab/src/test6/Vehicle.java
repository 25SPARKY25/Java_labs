package test6;

public class Vehicle {
	private int speed=0,qofpass=0;
	private String tip="", tip_of_vehicle="";
	//������� ��������

	public Vehicle(String tip, int speed, int qofpass, String tip_of_vehicle)
	{
		this.speed=speed;
		this.qofpass=qofpass;
		this.tip=tip;
		this.tip_of_vehicle=tip_of_vehicle;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getQofpass() {
		return qofpass;
	}

	public void setQofpass(int qofpass) {
		this.qofpass = qofpass;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}
	
	public String getTip_of_vehicle() {
		return tip_of_vehicle;
	}

	public void setTip_of_vehicle(String tip_of_vehicle) {
		this.tip_of_vehicle = tip_of_vehicle;
	}
	
}