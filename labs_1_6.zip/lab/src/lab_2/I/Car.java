package lab_2.I;

public class Car implements Vehicle {
private String tip_of_car="";
private int speed=0,qofpass=0;
private String tip="";

public Car(String tip, int speed, int qofpass, String tip_of_car)
{
	this.speed=speed;
	this.qofpass=qofpass;
	this.tip=tip;
	this.tip_of_car=tip_of_car;
}

public String getTip_of_car() {
	return tip_of_car;
}

public void setTip_of_car(String tip_of_car) {
	this.tip_of_car = tip_of_car;
}

@Override
public int getSpeed() {
	// TODO Auto-generated method stub
	return speed;
}

@Override
public int getqofpass() {
	// TODO Auto-generated method stub
	return qofpass;
}

@Override
public String getTip() {
	// TODO Auto-generated method stub
	return tip;
}

@Override
public void setSpeed(int sp) {
	// TODO Auto-generated method stub
	this.speed=sp;
}

@Override
public void setqofpass(int qop) {
	// TODO Auto-generated method stub
	this.qofpass=qop;
}

@Override
public void setTip(String t) {
	// TODO Auto-generated method stub
	this.tip=t;
}

public int getpass() //�������� ��������� ���������� ����������
{
	return this.getqofpass()-1;
}

}
