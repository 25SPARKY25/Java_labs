package lab_2.A;

public class Car extends Vehicle{
private String tip_of_car="";

public Car(String tip, int speed, int qofpass, String tip_of_car)
{
	super(speed, qofpass, tip);
	this.tip_of_car=tip_of_car;
}

public String getTip_of_car() {
	return tip_of_car;
}

public void setTip_of_car(String tip_of_car) {
	this.tip_of_car = tip_of_car;
}

@Override
public int getSpeed() {
	// TODO Auto-generated method stub
	return super.getSpeed();
}


@Override
public void setSpeed(int speed) {
	// TODO Auto-generated method stub
	super.setSpeed(speed);
}


@Override
public int getQofpass() {
	// TODO Auto-generated method stub
	return super.getQofpass();
}


@Override
public void setQofpass(int qofpass) {
	// TODO Auto-generated method stub
	super.setQofpass(qofpass);
}


@Override
public String getTip() {
	// TODO Auto-generated method stub
	return super.getTip();
}


@Override
public void setTip(String tip) {
	// TODO Auto-generated method stub
	super.setTip(tip);
}


public int getpass() //�������� ��������� ���������� ����������
{
	return this.getQofpass()-1;
}

}
