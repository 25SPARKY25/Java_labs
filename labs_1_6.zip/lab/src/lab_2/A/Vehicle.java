package lab_2.A;

public abstract class Vehicle {
	private int speed=0,qofpass=0;
	private String tip="";
	
	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getQofpass() {
		return qofpass;
	}

	public void setQofpass(int qofpass) {
		this.qofpass = qofpass;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}
	
	//������� ��������
	
	public Vehicle(int speed, int qofpass, String tip)
	{
		this.speed=speed;
		this.qofpass=qofpass;
		this.tip=tip;
	}
}